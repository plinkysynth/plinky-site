Deadriot is the experimental alias of Dennis Radtke & Markus Joos.

Celebrating the release of Plinky+, their exclusively synth-focussed Bank of 32 Presets explores their love for warm and wide expressive pads and arps. 

Easily moving through Dark Techno, Rave, Ambient & Broken Beats in their own music, Deadriot's preset bank reflects a passion for carefully crafting sounds that gives their own tracks their warmth and definition, and packs a punch on a club system.

Find Deadriot's music on

https://soundcloud.com/deadriot_ncn
https://deariotkm.bandcamp.com/



This pack includes:

- the preset file: PRESETS.UF2
- PDF with notes and sweet spots for each patch: plinky-presets-deadriot-2025-v.1.0.pdf
- Individual links for the patch editor at https://plinkysynth.github.io/editor/

This Preset Bank works for Plinky and Plinky+.
It uses the default wavetable, included here in case you have an alternate one installed: wavetab.uf2

The Bank does not use samples, so you don't have to upload any.



Find instructions on how to install presets under https://plinkysynth.com/presets




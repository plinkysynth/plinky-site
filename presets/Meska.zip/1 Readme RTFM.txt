Hey, 

here 32 presets for Plinky and Plinky+, written on Firmware 0.A1 (and tested on 0.A2, too).
 
They are focussed on the "dark" side of plinky, with pitch drift and noise.
The presets make use of some the remaining bugs and glitches, so changing the firmware might change the sound of some presets.
Each preset has a small sequence as a sound example, so hit the play button :)

Each preset uses KNOB A as "master sensitivity" - so with A at ZERO you will hear NO SOUND.
Some preset have KNOB B assigned as well, try wiggling B to find out what it does.



To upload the presets:

- unplug all cables from Plinky
- connect USB to your Plinky
- do not power from Eurorack at the same time, and use only one USB port
- hold down the encoder (rightmost knob), and plug the USB cable into your computer

Plinky will show up as a drive and you should see the "tunnel of lights" effect on its LEDs.

- If you want a backup of your Plinky before replacing the presets, now is the time to copy the content of Plinky to a folder on your PC
- Drag and drop PRESETS.uf2 to the drive. Make sure that it's called PRESETS.uf2 - do not rename.
- Drag and drop SAMPLE0.uf2, SAMPLE1.uf2 .. SAMPLE7.UF2. There are 8 files. You will have to copy them one by one, one after the other

While flashing, the LEDs will flicker. This is normal.

- when you are done copying the files, the "tunnel of lights" will appear again.
- press the encoder to reset and reboot Plinky. Done!



Some presets use the samples, so upload everything except this ReadMe and Links.txt.

The bank uses the default wavetable, included here in case you have an alternate one installed: wavetab.uf2


Always RTFM -
From France with love,
Meska

https://www.youtube.com/c/meska_statik
meskastatik@gmail.com

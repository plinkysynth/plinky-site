Grain Blanc 2 - Daylight

Ambient minimalist Grain Blanc explores a theme of light with his second preset bank for Plinky and Plinky+. 
Shimmery leads, glassy pads, undulating soundscapes and bright plucky arps draw you into exploring the dreamy side of Plinky's sound.

The bank comes with 8 new samples from Grain Blanc's vault, including Tongue drum, Synths, Koto and Pacifica. Check out Grain Blanc's hauntingly beautiful music.

Includes the preset and wavetable file, 8 samples and links for the patch editor.
On all patches, turn the A and B for knobs variations or reverb.

This Preset Bank works for Plinky and Plinky+.

Find Grain Blanc's music on:

https://grainblanc.bandcamp.com/
https://www.youtube.com/@grainblanc_
https://www.instagram.com/grainblanc_/



This pack includes:

- the preset file: PRESETS.UF2
- 8 new samples - Tongue drum, a few synths, Koto and Pacifica
- Individual links for the patch editor at https://plinkysynth.github.io/editor/

This Preset Bank works for Plinky and Plinky+.
It uses the default wavetable, included here in case you have an alternate one installed: wavetab.uf2


Find instructions on how to install presets under https://plinkysynth.com/presets



